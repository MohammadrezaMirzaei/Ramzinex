# Ramzinex
### This is the official python library for Ramzinex.com Cryptocurrency Exchange
##### Author: Mohammadreza Mirzaei
this is a test.
adding more functions.